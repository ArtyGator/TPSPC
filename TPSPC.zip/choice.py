import os
import tkinter as tk
from tkinter import font as tkFont
from tkinter import filedialog as tkfd
from functools import partial


def choice_file_open(starting_dir, invoker_window: tk.Toplevel):
    file_path = tkfd.askopenfilename(parent=invoker_window, filetypes=[("Classeur excel", '*.xlsx')],
                                     initialdir=starting_dir, title="Ouvrir une classe")
    return file_path


def choice_file_save(starting_dir, invoker_window: tk.Toplevel):
    file_path = tkfd.asksaveasfilename(parent=invoker_window, filetypes=[("Classeur excel", '*.xlsx')],
                                       initialdir=starting_dir, title="Sauvegarder les résultats",
                                       confirmoverwrite=False, defaultextension='.xlsx')
    return file_path


def choice_window(choices, wn_title=None, font_size=12):
    window = tk.Tk()
    window.title = wn_title

    default_font = tkFont.nametofont("TkDefaultFont")
    default_font.configure(size=font_size)  # modifie la taille de police par défaut
    window.option_add("*Font", default_font)

    if wn_title is not None:
        window.title = wn_title
    final_choice = None

    def quit_choiced(choiced):
        nonlocal final_choice
        final_choice = choiced
        window.destroy()

    for choice in choices:
        tk.Button(window, text=choice, command=partial(quit_choiced, choice)).pack(side='bottom', fill='x', ipadx=5,
                                                                                   ipady=5)

    window.mainloop()
    return final_choice


